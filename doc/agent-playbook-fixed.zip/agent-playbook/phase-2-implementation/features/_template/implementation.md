---
id: implementation
kind: artifact
phase: 2
feature: "<feature-slug>"
plan_ref: "F-NNN"
authors: [implementer]
status: in-progress   # in-progress | in-review | qa | merged
branch: "feature/<feature-slug>"
---

# Implementation — `<feature name>`

> The build record and the running trail of review → QA → merge. One artifact, four
> sections, filled in by the pipeline roles in order.

## What was built
A reviewer-friendly summary: the change, the approach, and how it maps to the discovery
docs. Link them:
`brainstorming` · `online-research` · `edge-case-analysis` · `architecture-analysis`.

## Key decisions & deviations
Where the build differed from the plan, and why. If the plan was wrong, note that it was
updated — don't diverge silently.

## How to verify
The steps a reviewer runs to see it work, and what was tested at each level.

## Checklist (author self-review before handoff)
- [ ] Acceptance criteria met and tested.
- [ ] No new `substrate.md` non-negotiable violated.
- [ ] Diff scoped to this feature; no drive-by changes.
- [ ] Local checks green (lint, type, test, build).
- [ ] No secrets in code, logs, or this doc.

---

## Adversarial review
_Filled by `adversarial-reviewer`. Findings most-severe first._

| Severity | Finding | Failing scenario | Status |
| --- | --- | --- | --- |
| | | | open / fixed / accepted |

**Verdict:** pass → pre-PR QA · fail → route by what broke: code wrong → implementer · plan wrong → senior-developer.

---

## Pre-PR QA
_Filled by `pre-pull-request-qa`. Each item pass/fail with evidence._

- [ ] Builds clean · [ ] Suite green · [ ] Acceptance criteria demonstrated
- [ ] Review findings resolved · [ ] Substrate red lines respected · [ ] No secrets
- [ ] Observability present · [ ] Docs updated · [ ] Diff scoped

**Verdict:** pass → promoter · fail → route by what broke: code → implementer · plan → senior-developer · untestable criterion → test-strategist.

---

## Post-merge
_Filled by `post-pull-request-qa`._

- **Deploy/rollout result:** `<...>`
- **Health over the watch window:** `<error rate, latency, key metric>`
- **Success metric status:** `<moving? baseline set?>`
- **Follow-ups → feature-plan (Source: Phase 3):** `<...>`
